package question02;
/**
 * This program will reverse the order of numbers for a positive integer using 
 * a recursive method
 * @author Adam Cichoski4
 * Assignment05 Question02
 */
public class Question02 {

    public static void main(String[] args) {
        int negative = -5;
        int[] numbers = {123, 54321, 1010, 1002, 729467, 0, 987654321};
       
        System.out.printf("%-15s %-1s \n","Original:", "Reversed:");
        for (int i=0;i<numbers.length;i++){
            System.out.printf("%-15d %-1d \n", numbers[i], reverse(numbers[i]));
        }
        //This is a test case for a negative number
        try{
            System.out.println(reverse(negative));
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    /**
     * This method will take an integer and perform some arithmetic to reverse 
     * the order of numbers
     * @param num is the original number that will be flipped
     * @param newNum is the variable that will hold the new number
     * @return the flipped number
     * IllegalArgumentException for when the inputted number is negative
     */
    private static int reverse1(int num, int newNum){
        if(num<0){
            throw new IllegalArgumentException("Number must be positive");
        }
        if(num==0){
            return newNum;
        }
        newNum = (newNum*10)+ (num%10);//I did this to add each number to newNum one by one
        num = (num-(num%10))/10; //Once the number is divisible by 10, I have to divide by ten so I can move onto the next number
        return reverse1(num,newNum);
    }
    /**
     * This method is used to take in the users number that needs to be reversed
     * and returns the reversed number 
     * @param num is the original number that will be reversed
     * @return reversed number (newNum)
     */
    public static int reverse(int num){
        int newNum=0;
        return reverse1(num,newNum);
    }
    
}
