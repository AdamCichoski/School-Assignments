package question04;
/**
 * This program will make and use two different methods to calculate a specific 
 * in the fibonacci sequence. The methods print their values separately, the second
 * method will take more time than the second to calculate higher indices.
 * @author Adam Cichoski
 * Assignment05 Question04
 */
public class Question04 {

    public static void main(String[] args) {
        int[] numbers = {1,2,3,4,5,6,7,8,9,10,20,30,40,45};
        System.out.println("    Fib good method");
        for(int i=0;i<numbers.length;i++){
            System.out.println(fib_good(numbers[i]));
        }
        System.out.println("    Fib bad method");
        for(int i=0;i<numbers.length;i++){
            System.out.println(fib_bad(numbers[i]));
        }
        
        //This is a test case for a negative index
//        try{
//            System.out.println(fib_bad(-1));
//        }
//        catch(Exception e){
//            System.out.println(e.toString());
//        }
    }
    /**
     * This method uses recursion to determine the value of an index in the 
     * fibonacci sequence, but without using dynamic programming
     * @param index is the desired index to be calculated in the sequence
     * @return the value of the given index
     * IllegalArumentException for the when index is less than zero, or if it would return an integer overflow
     */
    public static int fib_bad(int index){
        if (index < 0 || index > 46){
            throw new IllegalArgumentException("Index out of range");
        }
        if (index ==0 || index ==1){
            return index;
        }
        return fib_bad(index-1) +fib_bad(index-2);
    }
    /**
     * This method calculated a given index int eh fibonacci sequence using 
     * dynamic programming, saving the value in an array 
     * @param index is the desired index to find
     * @param storage is the array that stores already calculated values
     * @return the value at the given index 
     * IllegalArumentException for the when index is less than zero or if it would return an integer overflow
     */
    private static int fib1(int index, int[] storage){
        if (index < 0 || index > 46){
            throw new IllegalArgumentException("Index out of range");
        }
        if (index==1 || index ==0){
            return index;
        }
        if (storage[index]>0){
            return storage[index];
        }
        storage[index] = fib_bad(index-1) +fib_bad(index-2);
        return storage[index];
    }
    /**
     * This method is used to return the value in a given index of the fibonacci sequence
     * @param index is the desired index
     * @return the value at the index
     */
    public static int fib_good(int index){
        int[] storage= new int[index+1]; 
        return fib1(index, storage);
    } 
}
