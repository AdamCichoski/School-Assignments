package question03;
/**
 * This program will reverse a string in 2 separate ways: using a String, and 
 * then again using a StringBuffer instead
 * @author Adam Cichoski
 * Assignment05 Question03
 */
public class Question03 {
    public static void main(String[] args) {
        String[] str = {"a","","apple", "bacon", "honey", "milk"};
        System.out.printf("%-15s %-1s\n", "With String","With StringBuffer" );
        for (int i=0;i<str.length;i++){
            System.out.printf("%-15s %-1s\n",reverse1(str[i]), reverse2(str[i]));
        }
    }
    /**
     * This method will recursively run to reverse a string
     * @param s is the original string
     * @param position is the index of the character that will be taken from original string
     * @param result is the string that will hold the newly reversed string
     * @return reversed string
     */
    private static String reverse(String s, int position, String result){
        if(position <0){
            return result;
        }
        result+= s.charAt(position);
        return reverse(s,position-1,result);
    }
    /**
     * This method will reverse a string
     * @param s is the string that will be reversed 
     * @return reversed string
     */
    public static String reverse1(String s){
        if (s==""){
            return s;
        }
        String result="";
        int position = s.length()-1;
        return reverse(s, position,result);
    }
    /**
     * This method recursively adds letters to a StringBuffer to reverse a string
     * @param s is the original string that is being reversed
     * @param position is the index of the character the will be used in the original string
     * @param sb is a StringBuffer that will store the reversed string
     * @return the reversed string
     */
    private static StringBuffer reverse(String s, int position, StringBuffer sb){
        if(position <0){
            return sb;
        }
        sb.append(s.charAt(position));
        return reverse(s,position-1,sb);
    }
    /**
     * This method calls a private method to return a reversed string using a 
     * StringBuffer to make the process more memory efficient
     * @param s is the original string that will be reversed
     * @return the reversed string
     */
    public static String reverse2(String s){
        if (s==""){
            return s;
        }
        StringBuffer sb = new StringBuffer();
        int pos = s.length()-1;
        return reverse(s,pos,sb).toString();
    }
}
